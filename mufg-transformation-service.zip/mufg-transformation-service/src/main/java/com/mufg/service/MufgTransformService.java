package com.mufg.service;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface MufgTransformService {

	public String processTransformation(String payload) throws JsonParseException, JsonMappingException, IOException; 
	
}
