package com.mufg.wsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class AREA {

	@XmlElement(name = "REC")
	private REC REC;

	/**
	 * @return the rEC
	 */
	public REC getREC() {
		return REC;
	}

	/**
	 * @param rEC the rEC to set
	 */
	public void setREC(REC rEC) {
		REC = rEC;
	}
	
	
}
