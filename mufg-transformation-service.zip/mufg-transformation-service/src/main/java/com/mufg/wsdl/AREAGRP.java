package com.mufg.wsdl;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class AREAGRP {

	@XmlElement(name = "AREA")
	private List<AREA> AREA;

	/**
	 * @return the aREA
	 */
	public List<AREA> getAREA() {
		return AREA;
	}

	/**
	 * @param aREA the aREA to set
	 */
	public void setAREA(List<AREA> aREA) {
		AREA = aREA;
	}
	
	
	
}
