package com.mufg.wsdl;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Document")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class OutboundDocument implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private FileHeader fileHeader;

	private AREAGRP areaGRP;

	public static class AREAGRP {

		private CustomerHeader customerHeader;

		/**
		 * @return the customerHeader
		 */
		@XmlElement(name = "CustomerHeader")
		public CustomerHeader getCustomerHeader() {
			return customerHeader;
		}

		/**
		 * @param customerHeader the customerHeader to set
		 */
		public void setCustomerHeader(CustomerHeader customerHeader) {
			this.customerHeader = customerHeader;
		}

		public static class CustomerHeader {
			
			public ContactDetail contactDetails;

			/**
			 * @return the contactDetails
			 */

			@XmlElement(name = "ContactDetails")
			public ContactDetail getContactDetail() {
				return contactDetails;
			}

			/**
			 * @param contactDetails the contactDetails to set
			 */
			public void setContactDetail(ContactDetail contactDetail) {
				this.contactDetails = contactDetail;
			}

			
			public static class ContactDetail {

				private String contactID;

				
				private String customerName;
				private String attention;
				private String customerID;
				private String email;
				private String primaryFaxCountryCode;
				private String primaryFax;
				private String secondaryFaxCountryCode;
				private String secondaryFax;
				private String copyFax1CountryCode;
				private String copyFax1;
				private String copyFax2CountryCode;
				private String copyFax2;
				private String contactAddress1;
				private String contactAddress2;
				private String contactAddress3;
				private String contactAddress4;
				private String city;
				private String state;
				private String zip;
				private String country;
				private String bookingBranchNumber;
				private String operationBranchNumber;
				private String bookingCostCenterCode;
				private String responsibleCostCenterCode;

				/**
				 * @return the contactID
				 */
				@XmlElement(name = "ContactID")
				public String getContactID() {
					return contactID;
				}

				/**
				 * @param contactID the contactID to set
				 */
				public void setContactID(String contactID) {
					this.contactID = contactID;
				}

				/**
				 * @return the customerName
				 */

				@XmlElement(name = "CustomerName")
				public String getCustomerName() {
					return customerName;
				}

				/**
				 * @param customerName the customerName to set
				 */

				public void setCustomerName(String customerName) {
					this.customerName = customerName;
				}

				/**
				 * @return the attention
				 */

				@XmlElement(name = "Attention")
				public String getAttention() {
					return attention;
				}

				/**
				 * @param attention the attention to set
				 */

				public void setAttention(String attention) {
					this.attention = attention;
				}

				/**
				 * @return the customerID
				 */

				@XmlElement(name = "CustomerID")
				public String getCustomerID() {
					return customerID;
				}

				/**
				 * @param customerID the customerID to set
				 */

				public void setCustomerID(String customerID) {
					this.customerID = customerID;
				}

				/**
				 * @return the email
				 */

				@XmlElement(name = "Email")
				public String getEmail() {
					return email;
				}

				/**
				 * @param email the email to set
				 */

				public void setEmail(String email) {
					this.email = email;
				}

				/**
				 * @return the primaryFaxCountryCode
				 */

				@XmlElement(name = "PrimaryFaxCountryCode")
				public String getPrimaryFaxCountryCode() {
					return primaryFaxCountryCode;
				}

				/**
				 * @param primaryFaxCountryCode the primaryFaxCountryCode to set
				 */

				public void setPrimaryFaxCountryCode(String primaryFaxCountryCode) {
					this.primaryFaxCountryCode = primaryFaxCountryCode;
				}

				/**
				 * @return the primaryFax
				 */

				@XmlElement(name = "PrimaryFax")
				public String getPrimaryFax() {
					return primaryFax;
				}

				/**
				 * @param primaryFax the primaryFax to set
				 */

				public void setPrimaryFax(String primaryFax) {
					this.primaryFax = primaryFax;
				}

				/**
				 * @return the secondaryFaxCountryCode
				 */

				@XmlElement(name = "SecondaryFaxCountryCode")
				public String getSecondaryFaxCountryCode() {
					return secondaryFaxCountryCode;
				}

				/**
				 * @param secondaryFaxCountryCode the secondaryFaxCountryCode to set
				 */

				public void setSecondaryFaxCountryCode(String secondaryFaxCountryCode) {
					this.secondaryFaxCountryCode = secondaryFaxCountryCode;
				}

				/**
				 * @return the secondaryFax
				 */

				@XmlElement(name = "SecondaryFax")
				public String getSecondaryFax() {
					return secondaryFax;
				}

				/**
				 * @param secondaryFax the secondaryFax to set
				 */

				public void setSecondaryFax(String secondaryFax) {
					this.secondaryFax = secondaryFax;
				}

				/**
				 * @return the copyFax1CountryCode
				 */

				@XmlElement(name = "CopyFax1CountryCode")
				public String getCopyFax1CountryCode() {
					return copyFax1CountryCode;
				}

				/**
				 * @param copyFax1CountryCode the copyFax1CountryCode to set
				 */

				public void setCopyFax1CountryCode(String copyFax1CountryCode) {
					this.copyFax1CountryCode = copyFax1CountryCode;
				}

				/**
				 * @return the copyFax1
				 */

				@XmlElement(name = "CopyFax1")
				public String getCopyFax1() {
					return copyFax1;
				}

				/**
				 * @param copyFax1 the copyFax1 to set
				 */

				public void setCopyFax1(String copyFax1) {
					this.copyFax1 = copyFax1;
				}

				/**
				 * @return the copyFax2CountryCode
				 */

				@XmlElement(name = "CopyFax2CountryCode")
				public String getCopyFax2CountryCode() {
					return copyFax2CountryCode;
				}

				/**
				 * @param copyFax2CountryCode the copyFax2CountryCode to set
				 */

				public void setCopyFax2CountryCode(String copyFax2CountryCode) {
					this.copyFax2CountryCode = copyFax2CountryCode;
				}

				/**
				 * @return the copyFax2
				 */

				@XmlElement(name = "CopyFax2")
				public String getCopyFax2() {
					return copyFax2;
				}

				/**
				 * @param copyFax2 the copyFax2 to set
				 */

				public void setCopyFax2(String copyFax2) {
					this.copyFax2 = copyFax2;
				}

				/**
				 * @return the contactAddress1
				 */

				@XmlElement(name = "ContactAddress1")
				public String getContactAddress1() {
					return contactAddress1;
				}

				/**
				 * @param contactAddress1 the contactAddress1 to set
				 */

				public void setContactAddress1(String contactAddress1) {
					this.contactAddress1 = contactAddress1;
				}

				/**
				 * @return the contactAddress2
				 */

				@XmlElement(name = "ContactAddress2")
				public String getContactAddress2() {
					return contactAddress2;
				}

				/**
				 * @param contactAddress2 the contactAddress2 to set
				 */

				public void setContactAddress2(String contactAddress2) {
					this.contactAddress2 = contactAddress2;
				}

				/**
				 * @return the contactAddress3
				 */

				@XmlElement(name = "ContactAddress3")
				public String getContactAddress3() {
					return contactAddress3;
				}

				/**
				 * @param contactAddress3 the contactAddress3 to set
				 */

				public void setContactAddress3(String contactAddress3) {
					this.contactAddress3 = contactAddress3;
				}

				/**
				 * @return the contactAddress4
				 */

				@XmlElement(name = "ContactAddress4")
				public String getContactAddress4() {
					return contactAddress4;
				}

				/**
				 * @param contactAddress4 the contactAddress4 to set
				 */

				public void setContactAddress4(String contactAddress4) {
					this.contactAddress4 = contactAddress4;
				}

				/**
				 * @return the city
				 */

				@XmlElement(name = "City")
				public String getCity() {
					return city;
				}

				/**
				 * @param city the city to set
				 */

				public void setCity(String city) {
					this.city = city;
				}

				/**
				 * @return the state
				 */

				@XmlElement(name = "State")
				public String getState() {
					return state;
				}

				/**
				 * @param state the state to set
				 */

				public void setState(String state) {
					this.state = state;
				}

				/**
				 * @return the zip
				 */

				@XmlElement(name = "Zip")
				public String getZip() {
					return zip;
				}

				/**
				 * @param zip the zip to set
				 */

				public void setZip(String zip) {
					this.zip = zip;
				}

				/**
				 * @return the country
				 */

				@XmlElement(name = "Country")
				public String getCountry() {
					return country;
				}

				/**
				 * @param country the country to set
				 */

				public void setCountry(String country) {
					this.country = country;
				}

				/**
				 * @return the bookingBranchNumber
				 */

				@XmlElement(name = "BookingBranchNumber")
				public String getBookingBranchNumber() {
					return bookingBranchNumber;
				}

				/**
				 * @param bookingBranchNumber the bookingBranchNumber to set
				 */

				public void setBookingBranchNumber(String bookingBranchNumber) {
					this.bookingBranchNumber = bookingBranchNumber;
				}

				/**
				 * @return the operationBranchNumber
				 */

				@XmlElement(name = "OperationBranchNumber")
				public String getOperationBranchNumber() {
					return operationBranchNumber;
				}

				/**
				 * @param operationBranchNumber the operationBranchNumber to set
				 */

				public void setOperationBranchNumber(String operationBranchNumber) {
					this.operationBranchNumber = operationBranchNumber;
				}

				/**
				 * @return the bookingCostCenterCode
				 */

				@XmlElement(name = "BookingCostCenterCode")
				public String getBookingCostCenterCode() {
					return bookingCostCenterCode;
				}

				/**
				 * @param bookingCostCenterCode the bookingCostCenterCode to set
				 */

				public void setBookingCostCenterCode(String bookingCostCenterCode) {
					this.bookingCostCenterCode = bookingCostCenterCode;
				}

				/**
				 * @return the responsibleCostCenterCode
				 */

				@XmlElement(name = "ResponsibleCostCenterCode")
				public String getResponsibleCostCenterCode() {
					return responsibleCostCenterCode;
				}

				/**
				 * @param responsibleCostCenterCode the responsibleCostCenterCode to set
				 */
				public void setResponsibleCostCenterCode(String responsibleCostCenterCode) {
					this.responsibleCostCenterCode = responsibleCostCenterCode;
				}
						 

			}

			
		}

	}

	/**
	 * @return the areaGRP
	 */
	@XmlElement(name = "AREAGRP")
	public AREAGRP getAreaGRP() {
		return areaGRP;
	}

	/**
	 * @param areaGRP the areaGRP to set
	 */
	public void setAreaGRP(AREAGRP areaGRP) {
		this.areaGRP = areaGRP;
	}

	/**
	 * @return the fileHeader
	 */
	@XmlElement(name = "FileHeader")
	public FileHeader getFileHeader() {
		return fileHeader;
	}

	/**
	 * @param fileHeader the fileHeader to set
	 */
	public void setFileHeader(FileHeader fileHeader) {
		this.fileHeader = fileHeader;
	}

	public static class FileHeader {

		private Information information;

		public static class Information {

			private String systemName;

			private String product;

			private String dateCreated;

			private String dateTime;

			private String userCreated;

			private String userApproved;

			private String reportID;

			private String uniqueID;

			private String reportName;

			private String areaGroupCount;

			private String docFormat;

			/**
			 * @return the systemName
			 */
			@XmlElement(name = "SystemName")
			public String getSystemName() {
				return systemName;
			}

			/**
			 * @param systemName the systemName to set
			 */
			public void setSystemName(String systemName) {
				this.systemName = systemName;
			}

			/**
			 * @return the product
			 */
			@XmlElement(name = "Product")
			public String getProduct() {
				return product;
			}

			/**
			 * @param product the product to set
			 */
			public void setProduct(String product) {
				this.product = product;
			}

			/**
			 * @return the dateCreated
			 */
			@XmlElement(name = "DateCreated")
			public String getDateCreated() {
				return dateCreated;
			}

			/**
			 * @param dateCreated the dateCreated to set
			 */
			public void setDateCreated(String dateCreated) {
				this.dateCreated = dateCreated;
			}

			/**
			 * @return the dateTime
			 */
			@XmlElement(name = "DateTime")
			public String getDateTime() {
				return dateTime;
			}

			/**
			 * @param dateTime the dateTime to set
			 */
			public void setDateTime(String dateTime) {
				this.dateTime = dateTime;
			}

			/**
			 * @return the userCreated
			 */
			@XmlElement(name = "UserCreated")
			public String getUserCreated() {
				return userCreated;
			}

			/**
			 * @param userCreated the userCreated to set
			 */
			public void setUserCreated(String userCreated) {
				this.userCreated = userCreated;
			}

			/**
			 * @return the userApproved
			 */
			@XmlElement(name = "UserApproved")
			public String getUserApproved() {
				return userApproved;
			}

			/**
			 * @param userApproved the userApproved to set
			 */
			public void setUserApproved(String userApproved) {
				this.userApproved = userApproved;
			}

			/**
			 * @return the reportID
			 */
			@XmlElement(name = "ReportID")
			public String getReportID() {
				return reportID;
			}

			/**
			 * @param reportID the reportID to set
			 */
			public void setReportID(String reportID) {
				this.reportID = reportID;
			}

			/**
			 * @return the uniqueID
			 */
			@XmlElement(name = "UniqueID")
			public String getUniqueID() {
				return uniqueID;
			}

			/**
			 * @param uniqueID the uniqueID to set
			 */
			public void setUniqueID(String uniqueID) {
				this.uniqueID = uniqueID;
			}

			/**
			 * @return the reportName
			 */
			@XmlElement(name = "ReportName")
			public String getReportName() {
				return reportName;
			}

			/**
			 * @param reportName the reportName to set
			 */
			public void setReportName(String reportName) {
				this.reportName = reportName;
			}

			/**
			 * @return the areaGroupCount
			 */
			@XmlElement(name = "AreaGroupCount")
			public String getAreaGroupCount() {
				return areaGroupCount;
			}

			/**
			 * @param areaGroupCount the areaGroupCount to set
			 */
			public void setAreaGroupCount(String areaGroupCount) {
				this.areaGroupCount = areaGroupCount;
			}

			/**
			 * @return the docFormat
			 */
			@XmlElement(name = "DocFormat")
			public String getDocFormat() {
				return docFormat;
			}

			/**
			 * @param docFormat the docFormat to set
			 */
			public void setDocFormat(String docFormat) {
				this.docFormat = docFormat;
			}

		}

		/**
		 * @return the information
		 */
		@XmlElement(name = "Information")
		public Information getInformation() {
			return information;
		}

		/**
		 * @param information the information to set
		 */
		public void setInformation(Information information) {
			this.information = information;
		}

	}

}
