package com.mufg.wsdl;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class REC {

	@XmlElement(name = "FLD")
	private List<FLD> FLD;

	/**
	 * @return the fLD
	 */
	public List<FLD> getFLD() {
		return FLD;
	}

	/**
	 * @param fLD the fLD to set
	 */
	public void setFLD(List<FLD> fLD) {
		FLD = fLD;
	}
	
	
}
