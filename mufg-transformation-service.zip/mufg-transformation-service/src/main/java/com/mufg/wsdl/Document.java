package com.mufg.wsdl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class Document {

	@XmlElement(name = "AREA")
	private AREA AREA;
	
	@XmlElement(name = "AREAGRP")
	private AREAGRP AREAGRP;

	/**
	 * @return the aREA
	 */
	public AREA getAREA() {
		return AREA;
	}

	/**
	 * @param aREA the aREA to set
	 */
	public void setAREA(AREA aREA) {
		AREA = aREA;
	}

	/**
	 * @return the aREAGRP
	 */
	public AREAGRP getAREAGRP() {
		return AREAGRP;
	}

	/**
	 * @param aREAGRP the aREAGRP to set
	 */
	public void setAREAGRP(AREAGRP aREAGRP) {
		AREAGRP = aREAGRP;
	}
	
	
	
}	
