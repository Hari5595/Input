package com.mufg.us.amh.vln_ced_401.model;

import lombok.Data;


@Data
public class SearchKey {

	private SearchFields searchFields;
	
}
