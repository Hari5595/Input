package com.mufg.us.amh.vln_ced_401.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.mufg.us.amh.vln_ced_401.service.MufgTransformService;
import com.mufg.us.amh.vln_ced_401.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MufgQueueListener {

	@Autowired
	private MufgTransformService service;
	
	@JmsListener(destination = "${receiver.order}")
	public void receiveMessage(final Message jsonMessage) throws JAXBException, JMSException{
		String processId = CommonUtil.generateUniqueId();
		log.info("MufgListener ::receiveMessage() " + processId);
		if(jsonMessage instanceof TextMessage) {
			TextMessage textMessage = (TextMessage)jsonMessage;
			log.info("MufgListener :: Received message " + jsonMessage);
			String payload = textMessage.getText().trim();
			service.processTransformation(payload,processId);
		}
	}

}
