package com.mufg.us.amh.vln_ced_401.listener;

import javax.jms.JMSException;
import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MufgQueueSender {

	@Autowired
	JmsTemplate template;
	
	@Value("${destination.order}")
	private String destinationName	;
	
	public void sendMessage(String marhallData,String processId) throws JAXBException, JMSException{
		log.info("MufgListener ::receiveMessage() " + processId);
		template.convertAndSend(destinationName, marhallData);
	}

}
