package com.mufg.us.amh.vln_ced_401.binding;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.mufg.us.amh.vln_ced_401.binding.Document.AREA.REC;


@XmlRootElement(name = "Document")
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"fileHeader", "areaGRP"})
public class OutboundDocument implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private FileHeader fileHeader;
	
	
	/**
	 * @return the fileHeader
	 */
	@XmlElement(name = "FileHeader")
	public FileHeader getFileHeader() {
		return fileHeader;
	}

	/**
	 * @param fileHeader the fileHeader to set
	 */
	public void setFileHeader(FileHeader fileHeader) {
		this.fileHeader = fileHeader;
	}

	public static class FileHeader {

		private Information Information;
		
		@XmlAccessorType(XmlAccessType.FIELD)
		@XmlType(propOrder = {"SystemName","Product","DateCreated","DateTime","UserCreated","UserApproved","ReportID","UniqueID","ReportName","AreaGroupCount","DocFormat","PageCount"})
		public static class Information {

			
			private String SystemName;

			private String Product;
		
			private String DateCreated;

			private String DateTime;

			private String UserCreated;

			private String UserApproved;

			private String ReportID;

			private String UniqueID;

			private String ReportName;

			private String AreaGroupCount;

			private String DocFormat;

			private String PageCount ;	
			

			public String getSystemName() {
				return SystemName;
			}

			public void setSystemName(String systemName) {
				SystemName = systemName;
			}

			/**
			 * @return the product
			 */
			//@XmlElement(name = "Product")
			public String getProduct() {
				return Product;
			}

			/**
			 * @param product the product to set
			 */
			public void setProduct(String product) {
				this.Product = product;
				//this.product = "".equals(product) ? null : product;
			}

			/**
			 * @return the dateCreated
			 */
			//@XmlElement(name = "DateCreated")
			public String getDateCreated() {
				return DateCreated;
			}

			/**
			 * @param dateCreated the dateCreated to set
			 */
			public void setDateCreated(String dateCreated) {
				this.DateCreated = dateCreated;
				//this.dateCreated = "".equals(dateCreated) ? null : dateCreated;
			}

			/**
			 * @return the dateTime
			 */
			//@XmlElement(name = "DateTime")
			public String getDateTime() {
				return DateTime;
			}

			/**
			 * @param dateTime the dateTime to set
			 */
			public void setDateTime(String dateTime) {
				this.DateTime = dateTime;
				//this.dateTime = "".equals(dateTime) ? null : dateTime;
			}

			/**
			 * @return the userCreated
			 */
			//@XmlElement(name = "UserCreated")
			public String getUserCreated() {
				return UserCreated;
			}

			/**
			 * @param userCreated the userCreated to set
			 */
			public void setUserCreated(String userCreated) {
				this.UserCreated = userCreated;
				//this.userCreated = "".equals(userCreated) ? null : userCreated;
			}

			/**
			 * @return the userApproved
			 */
			//@XmlElement(name = "UserApproved")
			public String getUserApproved() {
				return UserApproved;
			}

			/**
			 * @param userApproved the userApproved to set
			 */
			public void setUserApproved(String userApproved) {
				this.UserApproved = userApproved;
				//this.userApproved = "".equals(userApproved) ? null : userApproved;
			}

			/**
			 * @return the reportID
			 */
			//@XmlElement(name = "ReportID")
			public String getReportID() {
				return ReportID;
			}

			/**
			 * @param reportID the reportID to set
			 */
			public void setReportID(String reportID) {
				this.ReportID = reportID;
				//this.reportID = "".equals(reportID) ? null : reportID;
			}

			/**
			 * @return the uniqueID
			 */
			//@XmlElement(name = "UniqueID")
			public String getUniqueID() {
				return UniqueID;
			}

			/**
			 * @param uniqueID the uniqueID to set
			 */
			public void setUniqueID(String uniqueID) {
				this.UniqueID = uniqueID;
				//this.uniqueID = "".equals(uniqueID) ? null : uniqueID;
			}

			/**
			 * @return the reportName
			 */
			//@XmlElement(name = "ReportName")
			public String getReportName() {
				return ReportName;
			}

			/**
			 * @param reportName the reportName to set
			 */
			public void setReportName(String reportName) {
				this.ReportName = reportName;
				//this.reportName = "".equals(reportName) ? null : reportName;
			}

			/**
			 * @return the areaGroupCount
			 */
			//@XmlElement(name = "AreaGroupCount")
			public String getAreaGroupCount() {
				return AreaGroupCount;
			}

			/**
			 * @param areaGroupCount the areaGroupCount to set
			 */
			public void setAreaGroupCount(String areaGroupCount) {
				this.AreaGroupCount = areaGroupCount;
				//this.areaGroupCount = "".equals(areaGroupCount) ? null : areaGroupCount;
			}

			/**
			 * @return the docFormat
			 */
			//@XmlElement(name = "DocFormat")
			public String getDocFormat() {
				return DocFormat;
			}

			/**
			 * @param docFormat the docFormat to set
			 */
			public void setDocFormat(String docFormat) {
				this.DocFormat = docFormat;
				//this.docFormat = "".equals(docFormat) ? null : docFormat;
			}

			public String getPageCount() {
				return PageCount;
			}

			public void setPageCount(String pageCount) {
				PageCount = pageCount;
			}
			
			

		}

		/**
		 * @return the information
		 */
		//@XmlElement(name = "Information")
		public Information getInformation() {
			return Information;
		}

		/**
		 * @param information the information to set
		 */
		public void setInformation(Information information) {
			this.Information = Information;
		}

	}
	
	
	private AREAGRP areaGRP;
	
	
	 @XmlAccessorType(XmlAccessType.FIELD)
	 @XmlType(propOrder = {"customerHeader","searchKey","body"})
    public static class AREAGRP {


		 //***** Body ****	
		 
			private Body body;
		
			/**
			 * @return the body
			 */
			//@XmlElement(name = "Body")
			public Body getBody() {
				return body;
			}

			/**
			 * @param body the body to set
			 */
			public void setBody(Body body) {
				this.body = body;
			}

			public static class Body{
				
				private FILE file;
				
				/**
				 * @return the file
				 */
				@XmlElement(name = "FILE")
				public FILE getFile() {
					return file;
				}



				/**
				 * @param file the file to set
				 */
				public void setFile(FILE file) {
					this.file = file;
				}



				public static class FILE{
					
					private String name;
					
					
					private List<REC> REC;

					/**
					 * @return the rec
					 */
					@XmlElement(name = "REC")
					public List<REC> getRec() {
						return REC;
					}

					/**
					 * @param rec the rec to set
					 */
					public void setRec(List<REC> rec) {
						this.REC = rec;
					}

					/**
					 * @return the name
					 */
					@XmlAttribute(name = "NAME")
					public String getName() {
						return name;
					}

					/**
					 * @param name the name to set
					 */
					public void setName(String name) {
						this.name = name;
					}
					
					
					
				} 
				
				
			}
		
		
		
		//*****   SearchKey	****		
		
		private SearchKey searchKey;
		
		/**
		 * @return the searchKey
		 */
		//@XmlElement(name = "SearchKey")
		public SearchKey getSearchKey() {
			return searchKey;
		}

		/**
		 * @param searchKey the searchKey to set
		 */
		public void setSearchKey(SearchKey SearchKey) {
			searchKey = SearchKey;
		}

		public static class  SearchKey{
			
			private SearchFields searchFields;
			
			/**
			 * @return the searchFields
			 */
			//@XmlElement(name = "SearchFields")
			public SearchFields getSearchFields() {
				return searchFields;
			}



			/**
			 * @param searchFields the searchFields to set
			 */
			public void setSearchFields(SearchFields searchFields) {
				this.searchFields = searchFields;
			}



			public static class SearchFields {
				
				private String customerName;
				private String customerNumber;
				private String branchCode;
				private String transactionNumber;
				private String currentOustandingAmount;
				private String transactionType;
				private String transactionEffectiveDate;
				private String facilityNumber;
				/**
				 * @return the customerName
				 */
				@XmlElement(name="CustomerName")
				public String getCustomerName() {
					return customerName;
				}
				/**
				 * @param customerName the customerName to set
				 */
				public void setCustomerName(String customerName) {
					this.customerName = customerName;
				}
				/**
				 * @return the customerNumber
				 */
				@XmlElement(name="CustomerNumber")
				public String getCustomerNumber() {
					return customerNumber;
				}
				/**
				 * @param customerNumber the customerNumber to set
				 */
				public void setCustomerNumber(String customerNumber) {
					this.customerNumber = customerNumber;
				}
				/**
				 * @return the branchCode
				 */
				@XmlElement(name="BranchCode")
				public String getBranchCode() {
					return branchCode;
				}
				/**
				 * @param branchCode the branchCode to set
				 */
				public void setBranchCode(String branchCode) {
					this.branchCode = branchCode;
				}
				/**
				 * @return the transactionNumber
				 */
				@XmlElement(name="TransactionNumber")
				public String getTransactionNumber() {
					return transactionNumber;
				}
				/**
				 * @param transactionNumber the transactionNumber to set
				 */
				public void setTransactionNumber(String transactionNumber) {
					//this.transactionNumber = transactionNumber;
					this.transactionNumber = "".equals(transactionNumber) ? null : transactionNumber;
				}
				/**
				 * @return the currentOustandingAmount
				 */
				@XmlElement(name="CurrentOustandingAmount")
				public String getCurrentOustandingAmount() {
					return currentOustandingAmount;
				}
				/**
				 * @param currentOustandingAmount the currentOustandingAmount to set
				 */
				public void setCurrentOustandingAmount(String currentOustandingAmount) {
					//this.currentOustandingAmount = currentOustandingAmount;
					this.currentOustandingAmount = "".equals(currentOustandingAmount) ? null : currentOustandingAmount;
				}
				/**
				 * @return the transactionType
				 */
				@XmlElement(name="TransactionType")
				public String getTransactionType() {
					return transactionType;
				}
				/**
				 * @param transactionType the transactionType to set
				 */
				public void setTransactionType(String transactionType) {
					this.transactionType = transactionType;
					
				}
				/**
				 * @return the transactionEffectiveDate
				 */
				@XmlElement(name="TransactionEffectiveDate")
				public String getTransactionEffectiveDate() {
					return transactionEffectiveDate;
				}
				/**
				 * @param transactionEffectiveDate the transactionEffectiveDate to set
				 */
				public void setTransactionEffectiveDate(String transactionEffectiveDate) {
					this.transactionEffectiveDate = transactionEffectiveDate;
				}
				/**
				 * @return the facilityNumber
				 */
				@XmlElement(name="FacilityNumber")
				public String getFacilityNumber() {
					return facilityNumber;
				}
				/**
				 * @param facilityNumber the facilityNumber to set
				 */
				public void setFacilityNumber(String facilityNumber) {
					this.facilityNumber = facilityNumber;
				}
				
				
				
			}
			
		}
		
		
		
		
		private CustomerHeader customerHeader;

		/**
		 * @return the customerHeader
		 */
		//@XmlElement(name = "CustomerHeader")
		public CustomerHeader getCustomerHeader() {
			return customerHeader;
		}

		/**
		 * @param customerHeader the customerHeader to set
		 */
		public void setCustomerHeader(CustomerHeader customerHeader) {
			this.customerHeader = customerHeader;
		}

		public static class CustomerHeader {
			
			
			private ContactDetail contactDetails;

			/**
			 * @return the contactDetails
			 */

			@XmlElement(name = "ContactDetails")
			public ContactDetail getContactDetail() {
				return contactDetails;
			}

			/**
			 * @param contactDetails the contactDetails to set
			 */
			public void setContactDetail(ContactDetail contactDetail) {
				this.contactDetails = contactDetail;
			}

			
			public static class ContactDetail {

				private String contactID;
				private String customerName;
				private String attention;
				private String customerID;
				private String email;
				private String primaryFaxCountryCode;
				private String primaryFax;
				private String secondaryFaxCountryCode;
				private String secondaryFax;
				private String copyFax1CountryCode;
				private String copyFax1;
				private String copyFax2CountryCode;
				private String copyFax2;
				private String contactAddress1;
				private String contactAddress2;
				private String contactAddress3;
				private String contactAddress4;
				private String city;
				private String state;
				private String zip;
				private String country;
				private String bookingBranchNumber;
				private String operationBranchNumber;
				private String bookingCostCenterCode;
				private String responsibleCostCenterCode;

				/**
				 * @return the contactID
				 */
				@XmlElement(name = "ContactID")
				public String getContactID() {
					return contactID;
				}

				/**
				 * @param contactID the contactID to set
				 */
				public void setContactID(String contactID) {
					this.contactID = contactID;
				}

				/**
				 * @return the customerName
				 */

				@XmlElement(name = "CustomerName")
				public String getCustomerName() {
					return customerName;
				}

				/**
				 * @param customerName the customerName to set
				 */

				public void setCustomerName(String customerName) {
					this.customerName = customerName;
				}

				/**
				 * @return the attention
				 */

				@XmlElement(name = "Attention")
				public String getAttention() {
					return attention;
				}

				/**
				 * @param attention the attention to set
				 */

				public void setAttention(String attention) {
					this.attention = attention;
				}

				/**
				 * @return the customerID
				 */

				@XmlElement(name = "CustomerID")
				public String getCustomerID() {
					return customerID;
				}

				/**
				 * @param customerID the customerID to set
				 */

				public void setCustomerID(String customerID) {
					this.customerID = customerID;
				}

				/**
				 * @return the email
				 */

				@XmlElement(name = "Email")
				public String getEmail() {
					return email;
				}

				/**
				 * @param email the email to set
				 */

				public void setEmail(String email) {
					this.email = email;
				}

				/**
				 * @return the primaryFaxCountryCode
				 */

				@XmlElement(name = "PrimaryFaxCountryCode")
				public String getPrimaryFaxCountryCode() {
					return primaryFaxCountryCode;
				}

				/**
				 * @param primaryFaxCountryCode the primaryFaxCountryCode to set
				 */

				public void setPrimaryFaxCountryCode(String primaryFaxCountryCode) {
					this.primaryFaxCountryCode = primaryFaxCountryCode;
				}

				/**
				 * @return the primaryFax
				 */

				@XmlElement(name = "PrimaryFax")
				public String getPrimaryFax() {
					return primaryFax;
				}

				/**
				 * @param primaryFax the primaryFax to set
				 */

				public void setPrimaryFax(String primaryFax) {
					this.primaryFax = primaryFax;
				}

				/**
				 * @return the secondaryFaxCountryCode
				 */

				@XmlElement(name = "SecondaryFaxCountryCode")
				public String getSecondaryFaxCountryCode() {
					return secondaryFaxCountryCode;
				}

				/**
				 * @param secondaryFaxCountryCode the secondaryFaxCountryCode to set
				 */

				public void setSecondaryFaxCountryCode(String secondaryFaxCountryCode) {
					this.secondaryFaxCountryCode = secondaryFaxCountryCode;
				}

				/**
				 * @return the secondaryFax
				 */

				@XmlElement(name = "SecondaryFax")
				public String getSecondaryFax() {
					return secondaryFax;
				}

				/**
				 * @param secondaryFax the secondaryFax to set
				 */

				public void setSecondaryFax(String secondaryFax) {
					this.secondaryFax = secondaryFax;
				}

				/**
				 * @return the copyFax1CountryCode
				 */

				@XmlElement(name = "CopyFax1CountryCode")
				public String getCopyFax1CountryCode() {
					return copyFax1CountryCode;
				}

				/**
				 * @param copyFax1CountryCode the copyFax1CountryCode to set
				 */

				public void setCopyFax1CountryCode(String copyFax1CountryCode) {
					this.copyFax1CountryCode = copyFax1CountryCode;
				}

				/**
				 * @return the copyFax1
				 */

				@XmlElement(name = "CopyFax1")
				public String getCopyFax1() {
					return copyFax1;
				}

				/**
				 * @param copyFax1 the copyFax1 to set
				 */

				public void setCopyFax1(String copyFax1) {
					this.copyFax1 = copyFax1;
				}

				/**
				 * @return the copyFax2CountryCode
				 */

				@XmlElement(name = "CopyFax2CountryCode")
				public String getCopyFax2CountryCode() {
					return copyFax2CountryCode;
				}

				/**
				 * @param copyFax2CountryCode the copyFax2CountryCode to set
				 */

				public void setCopyFax2CountryCode(String copyFax2CountryCode) {
					this.copyFax2CountryCode = copyFax2CountryCode;
				}

				/**
				 * @return the copyFax2
				 */

				@XmlElement(name = "CopyFax2")
				public String getCopyFax2() {
					return copyFax2;
				}

				/**
				 * @param copyFax2 the copyFax2 to set
				 */

				public void setCopyFax2(String copyFax2) {
					this.copyFax2 = copyFax2;
				}

				/**
				 * @return the contactAddress1
				 */

				@XmlElement(name = "ContactAddress1")
				public String getContactAddress1() {
					return contactAddress1;
				}

				/**
				 * @param contactAddress1 the contactAddress1 to set
				 */

				public void setContactAddress1(String contactAddress1) {
					this.contactAddress1 = contactAddress1;
				}

				/**
				 * @return the contactAddress2
				 */

				@XmlElement(name = "ContactAddress2")
				public String getContactAddress2() {
					return contactAddress2;
				}

				/**
				 * @param contactAddress2 the contactAddress2 to set
				 */

				public void setContactAddress2(String contactAddress2) {
					this.contactAddress2 = contactAddress2;
				}

				/**
				 * @return the contactAddress3
				 */

				@XmlElement(name = "ContactAddress3")
				public String getContactAddress3() {
					return contactAddress3;
				}

				/**
				 * @param contactAddress3 the contactAddress3 to set
				 */

				public void setContactAddress3(String contactAddress3) {
					this.contactAddress3 = contactAddress3;
				}

				/**
				 * @return the contactAddress4
				 */

				@XmlElement(name = "ContactAddress4")
				public String getContactAddress4() {
					return contactAddress4;
				}

				/**
				 * @param contactAddress4 the contactAddress4 to set
				 */

				public void setContactAddress4(String contactAddress4) {
					this.contactAddress4 = contactAddress4;
				}

				/**
				 * @return the city
				 */

				@XmlElement(name = "City")
				public String getCity() {
					return city;
				}

				/**
				 * @param city the city to set
				 */

				public void setCity(String city) {
					this.city = city;
				}

				/**
				 * @return the state
				 */

				@XmlElement(name = "State")
				public String getState() {
					return state;
				}

				/**
				 * @param state the state to set
				 */

				public void setState(String state) {
					this.state = state;
				}

				/**
				 * @return the zip
				 */

				@XmlElement(name = "Zip")
				public String getZip() {
					return zip;
				}

				/**
				 * @param zip the zip to set
				 */

				public void setZip(String zip) {
					this.zip = zip;
				}

				/**
				 * @return the country
				 */

				@XmlElement(name = "Country")
				public String getCountry() {
					return country;
				}

				/**
				 * @param country the country to set
				 */

				public void setCountry(String country) {
					this.country = country;
				}

				/**
				 * @return the bookingBranchNumber
				 */

				@XmlElement(name = "BookingBranchNumber")
				public String getBookingBranchNumber() {
					return bookingBranchNumber;
				}

				/**
				 * @param bookingBranchNumber the bookingBranchNumber to set
				 */

				public void setBookingBranchNumber(String bookingBranchNumber) {
					this.bookingBranchNumber = bookingBranchNumber;
				}

				/**
				 * @return the operationBranchNumber
				 */

				@XmlElement(name = "OperationBranchNumber")
				public String getOperationBranchNumber() {
					return operationBranchNumber;
				}

				/**
				 * @param operationBranchNumber the operationBranchNumber to set
				 */

				public void setOperationBranchNumber(String operationBranchNumber) {
					this.operationBranchNumber = operationBranchNumber;
				}

				/**
				 * @return the bookingCostCenterCode
				 */

				@XmlElement(name = "BookingCostCenterCode")
				public String getBookingCostCenterCode() {
					return bookingCostCenterCode;
				}

				/**
				 * @param bookingCostCenterCode the bookingCostCenterCode to set
				 */

				public void setBookingCostCenterCode(String bookingCostCenterCode) {
					this.bookingCostCenterCode = bookingCostCenterCode;
				}

				/**
				 * @return the responsibleCostCenterCode
				 */

				@XmlElement(name = "ResponsibleCostCenterCode")
				public String getResponsibleCostCenterCode() {
					return responsibleCostCenterCode;
				}

				/**
				 * @param responsibleCostCenterCode the responsibleCostCenterCode to set
				 */
				public void setResponsibleCostCenterCode(String responsibleCostCenterCode) {
					this.responsibleCostCenterCode = responsibleCostCenterCode;
				}
						 

			}

			
			
			
		}

	}

	/**
	 * @return the areaGRP
	 */
	@XmlElement(name = "AREAGRP")
	public AREAGRP getAreaGRP() {
		return areaGRP;
	}

	/**
	 * @param areaGRP the areaGRP to set
	 */
	public void setAreaGRP(AREAGRP areaGRP) {
		this.areaGRP = areaGRP;
	}

	

}
