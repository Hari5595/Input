package com.mufg.us.amh.vln_ced_401.constants;

public class AppConstants {
	
	
	public static final String DEFAULT_DOC_FORMAT = "XML";
	public static final String EMPTY_VALUE = "";

}
