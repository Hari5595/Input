package com.mufg.us.amh.vln_ced_401.jmsconfig;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mufg.us.amh.vln_ced_401.transformation.MufgTransformService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MufgListener {

	@Autowired
	private MufgTransformService service;
	
	@JmsListener(destination = "ev.inbound.queue")
	@SendTo("ev.outbound.queue")
	public String receiveMessage(final Message jsonMessage) throws JMSException, JsonParseException, JsonMappingException, IOException {
		String transformedStringData = null;
		log.info("MufgListener :: Received message " + jsonMessage);
		if(jsonMessage instanceof TextMessage) {
			TextMessage textMessage = (TextMessage)jsonMessage;
			transformedStringData = service.processTransformation(textMessage.getText());
			log.info("MufgListener :: Sent message successfully");
		}
		return transformedStringData;
	}

}
