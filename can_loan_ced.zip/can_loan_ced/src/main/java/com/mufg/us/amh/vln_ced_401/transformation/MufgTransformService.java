package com.mufg.us.amh.vln_ced_401.transformation;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mufg.us.amh.vln_ced_401.binding.Document;
import com.mufg.us.amh.vln_ced_401.binding.FLD;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument;
import com.mufg.us.amh.vln_ced_401.binding.Document.AREA.REC;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.AREAGRP;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.FileHeader;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.AREAGRP.Body;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.AREAGRP.CustomerHeader;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.AREAGRP.SearchKey;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.AREAGRP.Body.FILE;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.AREAGRP.CustomerHeader.ContactDetail;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.AREAGRP.SearchKey.SearchFields;
import com.mufg.us.amh.vln_ced_401.binding.OutboundDocument.FileHeader.Information;
import com.mufg.us.amh.vln_ced_401.constants.AppConstants;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MufgTransformService {

	
	public String processTransformation(String payload) throws JsonParseException, JsonMappingException, IOException {
		log.info("MufgTransformService :: processEnrich() :: Init");
		Document unMarshalDocument = this.unmarshalDocument(payload);
		String marshalDocument = this.marshalDocument(unMarshalDocument);
		log.info("MufgTransformService :: processEnrich() :: Ends");
		return marshalDocument;
				
	}
	
	private String marshalDocument(Document unMarshalDocument) {
		StringWriter sw = new StringWriter();
		try {
			//OutDoc prepare starts
			List<FLD> FLDS = unMarshalDocument.getAREA().getREC().get(0).getFLD();
			//Header info prepare starts
			OutboundDocument outboundDocument = new OutboundDocument();
			Information Information = new Information();
			Information.setSystemName(FLDS.get(0).getValue());
			Information.setProduct(FLDS.get(1).getValue());
			Information.setDateCreated(FLDS.get(2).getValue());
			Information.setDateTime(FLDS.get(3).getValue());
			Information.setUserCreated(FLDS.get(4).getValue());
			Information.setUserApproved(FLDS.get(5).getValue());
			Information.setReportID(FLDS.get(6).getValue());
			Information.setUniqueID(FLDS.get(7).getValue());
			Information.setReportName(FLDS.get(8).getValue());
			Information.setAreaGroupCount(FLDS.get(9).getValue());
			Information.setDocFormat(AppConstants.DEFAULT_DOC_FORMAT);
			Information.setPageCount(AppConstants.EMPTY_VALUE);
			FileHeader header = new FileHeader();
			header.setInformation(Information);
			outboundDocument.setFileHeader(header);
			
			//Header info prepare starts
			List<FLD> CUSTOMER_FLDS = unMarshalDocument.getAREAGRP().getAREA().get(0).getREC().get(0).getFLD();
			//Customer details preparation starts
			ContactDetail contactDetails = new ContactDetail();
			contactDetails.setContactID(CUSTOMER_FLDS.get(0).getValue());
			contactDetails.setCustomerName(CUSTOMER_FLDS.get(1).getValue().trim());
			contactDetails.setAttention(CUSTOMER_FLDS.get(2).getValue());
			contactDetails.setCustomerID(CUSTOMER_FLDS.get(3).getValue());
			contactDetails.setEmail(CUSTOMER_FLDS.get(4).getValue().replaceAll("\\s+",""));
			contactDetails.setPrimaryFaxCountryCode(CUSTOMER_FLDS.get(5).getValue());
			contactDetails.setPrimaryFax(CUSTOMER_FLDS.get(6).getValue());
			contactDetails.setSecondaryFaxCountryCode(CUSTOMER_FLDS.get(7).getValue());
			contactDetails.setSecondaryFax(CUSTOMER_FLDS.get(8).getValue());
			contactDetails.setCopyFax1CountryCode(CUSTOMER_FLDS.get(9).getValue());
			contactDetails.setCopyFax1(CUSTOMER_FLDS.get(10).getValue());
			contactDetails.setCopyFax2CountryCode(CUSTOMER_FLDS.get(11).getValue());
			contactDetails.setCopyFax2(CUSTOMER_FLDS.get(12).getValue());
			contactDetails.setContactAddress1(CUSTOMER_FLDS.get(13).getValue().replaceAll("\\s+",""));
			contactDetails.setContactAddress2(CUSTOMER_FLDS.get(14).getValue().replaceAll("\\s+",""));
			contactDetails.setContactAddress3(CUSTOMER_FLDS.get(15).getValue());
			contactDetails.setContactAddress4(CUSTOMER_FLDS.get(16).getValue());
			contactDetails.setCity(CUSTOMER_FLDS.get(17).getValue().replaceAll("\\s+",""));
			contactDetails.setState(CUSTOMER_FLDS.get(18).getValue());
			contactDetails.setZip(CUSTOMER_FLDS.get(19).getValue().replaceAll("\\s+",""));
			contactDetails.setCountry(CUSTOMER_FLDS.get(20).getValue().replaceAll("\\s+",""));
			contactDetails.setBookingBranchNumber(CUSTOMER_FLDS.get(21).getValue());
			contactDetails.setOperationBranchNumber(CUSTOMER_FLDS.get(22).getValue());
			contactDetails.setBookingCostCenterCode(CUSTOMER_FLDS.get(23).getValue());
			contactDetails.setResponsibleCostCenterCode(CUSTOMER_FLDS.get(24).getValue());
			CustomerHeader customerHeader = new CustomerHeader();
			customerHeader.setContactDetail(contactDetails);
			AREAGRP areaGRP = new AREAGRP();
			areaGRP.setCustomerHeader(customerHeader); 
			//Customer details preparation ends
			//SearchKey details starts
			List<FLD> SEARCH_FLDS = unMarshalDocument.getAREAGRP().getAREA().get(1).getREC().get(0).getFLD();
			SearchKey searchKey = new SearchKey();
			SearchFields searchFields = new SearchFields();
			searchFields.setCustomerName(SEARCH_FLDS.get(0).getValue());
			searchFields.setCustomerNumber(SEARCH_FLDS.get(1).getValue());
			searchFields.setBranchCode(SEARCH_FLDS.get(2).getValue());
			searchFields.setTransactionNumber(SEARCH_FLDS.get(3).getValue());
			searchFields.setCurrentOustandingAmount(SEARCH_FLDS.get(4).getValue());
			searchFields.setTransactionType(SEARCH_FLDS.get(0).getValue());
			searchFields.setTransactionEffectiveDate(SEARCH_FLDS.get(5).getValue());
			searchFields.setFacilityNumber(SEARCH_FLDS.get(6).getValue());
			searchKey.setSearchFields(searchFields);
			areaGRP.setSearchKey(searchKey);
			//SearchKey details ends
			
			
			Body body = new Body();
			FILE file = new FILE();
			
			REC IRISCONTACT = new REC();
			IRISCONTACT.setName("IRISCONTACT");
			List<FLD> IRISCONTACT_FIELDS = new ArrayList<>();
			FLD FLD = null;
			for(FLD fld : unMarshalDocument.getAREAGRP().getAREA().get(0).getREC().get(0).getFLD()) {
				FLD = new FLD();
				if(fld.getName().equalsIgnoreCase("ATTN")) {
					FLD.setName("AttentionName");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("CSTMRNM")) {
					FLD.setName("CustomerName");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("PSTLADR1")) {
					FLD.setName("Address1");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("PSTLADR2")) {
					FLD.setName("Address2");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("PSTLADR3")) {
					FLD.setName("Address3");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("PSTLADR4")) {
					FLD.setName("Address4");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("CITYNM")) {
					FLD.setName("City");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("STATNM")) {
					FLD.setName("State");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("PSTLCDDGTS")) {
					FLD.setName("Zip");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("CTRYNM")) {
					FLD.setName("Country");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("EMAILADR")) {
					FLD.setName("Emails");
					FLD.setValue(fld.getValue().replaceAll("\\s+",""));
					IRISCONTACT_FIELDS.add(FLD);
				}else if(fld.getName().equalsIgnoreCase("SCNDRYFAXNB")) {
					FLD.setName("Faxes");
					FLD.setValue(fld.getValue());
					IRISCONTACT_FIELDS.add(FLD);
				}
			}
			IRISCONTACT.setFLD(IRISCONTACT_FIELDS);
			
			REC PRTCNTT = new REC();
			PRTCNTT.setName("NOTICE");
			List<FLD> PRTCNTT_FIELDS = new ArrayList<>();
			for(FLD fld : unMarshalDocument.getAREAGRP().getAREA().get(0).getREC().get(0).getFLD()) {
				FLD = new FLD();
				FLD.setName(fld.getName());
				FLD.setValue(fld.getValue());
				PRTCNTT_FIELDS.add(FLD);
			}
			PRTCNTT.setFLD(PRTCNTT_FIELDS);
			
			REC NOTICE = new REC();
			NOTICE.setName("PRTCNTT");
			List<FLD> NOTICE_FIELDS = new ArrayList<>();
			for(FLD fld : unMarshalDocument.getAREAGRP().getAREA().get(2).getREC().get(0).getFLD()) {
				FLD = new FLD();
				FLD.setName(fld.getName());
				FLD.setValue(fld.getValue());
				NOTICE_FIELDS.add(FLD);
			}
			NOTICE.setFLD(NOTICE_FIELDS);
			
			List<REC> list_recs = new ArrayList<>();
			list_recs.add(0, IRISCONTACT);
			list_recs.add(1, NOTICE);
			list_recs.add(2, PRTCNTT);
			file.setRec(list_recs);
			file.setName("Data Design");
			body.setFile(file);
			
			areaGRP.setBody(body);
			
			outboundDocument.setAreaGRP(areaGRP);
			//OutDoc prepare ends
            JAXBContext jaxbContext = JAXBContext.newInstance(OutboundDocument.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE); // To format XML
            jaxbMarshaller.marshal(outboundDocument,System.out);
            jaxbMarshaller.marshal(outboundDocument, sw);
        } catch (JAXBException e) {
        	log.error("Exception occured  in marshaling and the exepion is :: " + e);
        }
		return sw.toString();
	}

	private Document unmarshalDocument(String payload) {
		Document doc = null ;
		try {
			JAXBContext jc = JAXBContext.newInstance(Document.class);
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			StreamSource streamSource = new StreamSource(new StringReader(payload));
			JAXBElement<Document> je = unmarshaller.unmarshal(streamSource, Document.class);
			doc = je.getValue();
			//log.info("Converted Value :: " + doc);
		} catch (JAXBException e) {
			log.error("Exception occured  in unmarshaling and the exepion is :: " + e);
		}
		return doc;
	}
	
	
	
}
