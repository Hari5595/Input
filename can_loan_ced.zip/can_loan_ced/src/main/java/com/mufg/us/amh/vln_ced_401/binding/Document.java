package com.mufg.us.amh.vln_ced_401.binding;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class Document {

	@XmlElement(name = "AREA")
	private AREA AREA;

	@XmlElement(name = "AREAGRP")
	private AREAGRP AREAGRP;

	/**
	 * @return the aREA
	 */
	public AREA getAREA() {
		return AREA;
	}

	/**
	 * @param aREA the aREA to set
	 */
	public void setAREA(AREA aREA) {
		AREA = aREA;
	}

	/**
	 * @return the aREAGRP
	 */
	public AREAGRP getAREAGRP() {
		return AREAGRP;
	}

	/**
	 * @param aREAGRP the aREAGRP to set
	 */
	public void setAREAGRP(AREAGRP aREAGRP) {
		AREAGRP = aREAGRP;
	}

	public static class AREAGRP {

		private List<AREA> AREA;

		/**
		 * @return the aREA
		 */
		@XmlElement(name = "AREA")
		public List<AREA> getAREA() {
			return AREA;
		}

		/**
		 * @param aREA the aREA to set
		 */
		public void setAREA(List<AREA> aREA) {
			AREA = aREA;
		}

	}

	public static class AREA {

		/*
		 * private REC;
		 * 
		 * 
		 * @XmlElement(name = "REC") public REC getREC() { return REC; }
		 * 
		 *//**
			 * @param rEC the rEC to set
			 *//*
				 * public void setREC(REC rEC) { REC = rEC; }
				 */

		 private List<REC> REC;
		 
		 
		
		/**
		 * @return the rEC
		 */
		@XmlElement(name = "REC")
		public List<REC> getREC() {
			return REC;
		}



		/**
		 * @param rEC the rEC to set
		 */
		public void setREC(List<REC> rEC) {
			REC = rEC;
		}


		@XmlRootElement(name="REC")
		public static class REC {
			
			private String NAME;

			private List<FLD> FLD;

			/**
			 * @return the fLD
			 */
			@XmlElement(name = "FLD")
			public List<FLD> getFLD() {
				 if( FLD == null ){
					 FLD = new ArrayList<>();
			     }
			     return FLD;
			}

			/**
			 * @param fLD the fLD to set
			 */
			public void setFLD(List<FLD> fLD) {
				FLD = fLD;
			}

			/**
			 * @return the name
			 */
			@XmlAttribute(name = "NAME")
			public String getName() {
				return NAME;
			}

			/**
			 * @param name the name to set
			 */
			public void setName(String name) {
				this.NAME = name;
			}

		}

	}

}
