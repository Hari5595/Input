package com.mufg.us.amh.y73.eip.sodeod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.annotation.EnableJms;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
@EnableJms
public class T360_CBH_505_503_SOD_EOD {

    /**
     * This is a Main Application to start & load Spring configurations
     *
     * @param args
     */
    public static void main(String[] args) throws Exception {
        SpringApplication.run(T360_CBH_505_503_SOD_EOD.class, args);
        log.debug("<<< ************************* T360_CBH_505_503_SOD_EOD **************************** >>>");
        log.debug("T360_CBH_505_503_SOD_EOD Service is Started Successfully...");
    }
}

