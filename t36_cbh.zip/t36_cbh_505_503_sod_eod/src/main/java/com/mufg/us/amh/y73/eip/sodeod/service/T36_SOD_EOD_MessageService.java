package com.mufg.us.amh.y73.eip.sodeod.service;

import com.mufg.us.amh.y73.eip.sdk.model.CBHInAdapterRequest;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKProponix;

public interface T36_SOD_EOD_MessageService {

	/**
	 * 
	 * @param t36sodRequestProponix
	 * @return
	 */
	T36ACKProponix prepareT36AckSODMessage(com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix t36sodRequestProponix);

	/**
	 * 
	 * @param t36eodRequestProponix
	 * @return
	 */
	T36ACKProponix prepareT36AckEODMessage(com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix t36eodRequestProponix);


	/**
	 * 
	 * @param t36eodRequestProponix
	 * @param inputXML
	 * @param exchangeID
	 * @return
	 */
	CBHInAdapterRequest prepareEODCBHInAdapterRequest(com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix t36eodRequestProponix, String inputXML,
			String exchangeID);

	/**
	 * 
	 * @param t36sodRequestProponix
	 * @param inputXML
	 * @param exchangeID
	 * @return
	 */
	CBHInAdapterRequest prepareSODCBHInAdapterRequest(com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix t36sodRequestProponix, String inputXML,
			String exchangeID);
	/**
	 * 
	 * @param errorCode
	 * @param errorText
	 * @param t36InputReqData
	 * @return
	 */
	T36ACKProponix setTransFailureT36AckMsg(String errorCode, String errorText, String t36InputReqData);

}