package com.mufg.us.amh.y73.eip.sodeod.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import com.mufg.us.amh.y73.eip.sdk.constant.CBHRequestConstant;
import com.mufg.us.amh.y73.eip.sdk.constant.T36CBHConstant;
import com.mufg.us.amh.y73.eip.sdk.model.CBHInAdapterRequest;
import com.mufg.us.amh.y73.eip.sodeod.service.T36_SOD_EOD_MessageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CBHMessageProccessor implements Processor {

	@Value("${spring.t36sodinputqname}")
	private String t36sodinputqname;

	@Value("${spring.t36eodinputqname}")
	private String t36eodinputqname;

	@Autowired
	private T36_SOD_EOD_MessageService t36_SOD_EOD_MessageService;

	public void process(Exchange exchange) throws Exception {
		XmlMapper xmlMapper = new XmlMapper();
		CBHInAdapterRequest cbhInAdapterRequest;
		com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix t36sodReqProponix;
		com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix t36eodReqProponix;
		try {
			if (exchange.getFromEndpoint().getEndpointUri().replace("activemq://queue:", "").equals(t36sodinputqname)) {
				// unmarshall T360 SOD input XML data
				
				t36sodReqProponix = (com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix) exchange.getProperty("T36SODRequestProponixObj");
				cbhInAdapterRequest = t36_SOD_EOD_MessageService.prepareSODCBHInAdapterRequest(t36sodReqProponix,
						exchange.getProperty(T36CBHConstant.T36_INPUT_XML_DATA_NAME).toString(),
						exchange.getExchangeId());
			} else {
				// unmarshall T360 EOD input XML data
				t36eodReqProponix = (com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix) exchange.getProperty("T36EODRequestProponixObj");
				cbhInAdapterRequest = t36_SOD_EOD_MessageService.prepareEODCBHInAdapterRequest(t36eodReqProponix,
						exchange.getProperty(T36CBHConstant.T36_INPUT_XML_DATA_NAME).toString(),
						exchange.getExchangeId());
			}
			xmlMapper.configure(ToXmlGenerator.Feature.WRITE_XML_DECLARATION, true);
			exchange.getIn().setHeader("CCSID", CBHRequestConstant.CBH_CCSID);
			exchange.getIn().setHeader("Encoding", CBHRequestConstant.CBH_ENCODING);
			exchange.getIn().setBody(xmlMapper.writeValueAsString(cbhInAdapterRequest)); // Convert to XML String and
																							// set message body
		} catch (Exception e) {
			log.error("CBHMessageProccessor: Failed to create CBH message {}", e.getMessage());
			exchange.setException(new Throwable(e.getMessage()));
		}
	}

}
