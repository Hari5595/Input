package com.mufg.us.amh.y73.eip.sodeod.processor;

import java.util.Calendar;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.mufg.us.amh.y73.eip.sdk.constant.T36CBHConstant;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKBody;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKHeader;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKProponix;
import com.mufg.us.amh.y73.eip.sodeod.service.T36_SOD_EOD_MessageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ExceptionMessageProccessor implements Processor {

	@Value("${spring.t36sodinputqname}")
	private String t36sodinputqname;

	@Autowired
	private T36_SOD_EOD_MessageService t36_SOD_EOD_MessageService;

	public void process(Exchange exchange) throws Exception {
		String t36InputXMLReqData = exchange.getProperty(T36CBHConstant.T36_INPUT_XML_DATA_NAME).toString();
		String errorText = exchange.getProperty(T36CBHConstant.CAMEL_EXCEPTION_CAUGHT).toString();
		com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix t36eodRequestProponix;
		com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix t36sodRequestProponix;
		T36ACKProponix t36ackProponix = new T36ACKProponix();
		T36ACKHeader t36ackHeader;
		T36ACKBody t36ackBody;
		XmlMapper mapper = new XmlMapper();
		exchange.getIn().setHeader("CCSID", T36CBHConstant.ACK_CCSID);
		exchange.getIn().setHeader("Encoding", T36CBHConstant.ACK_ENCODING);
		try {
			if (exchange.getFromEndpoint().getEndpointUri().replace("activemq://queue:", "").equals(t36sodinputqname)) {
				t36sodRequestProponix = (com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix) exchange
						.getProperty("T36SODRequestProponixObj");
				// Prepare T36 message for one of the XML field missing
				com.mufg.us.amh.y73.eip.sodeod.sodmodel.Header header = t36sodRequestProponix.getHeader();
				log.error(
						"ExceptionMessageProccessor: T36 SOD xml validation failed in T36ACKProccessor due to: {} for MessageType: {} and MessageID: {}",
						errorText, header.getMessageType(), header.getMessageID());
				t36ackHeader = new T36ACKHeader(header.getDestinationID(), header.getSenderID(),
						T36CBHConstant.ACK_MSG_TYPE, Calendar.getInstance().getTime(), Calendar.getInstance().getTime(),
						"128838301A"); // TODO: // Generate MessageID
				t36ackBody = new T36ACKBody(header.getMessageID(), T36CBHConstant.ACK_PROCSG_STATUS_FAIL,
						T36CBHConstant.ACK_ERR_CODE_MISSING, errorText);
			} else {
				t36eodRequestProponix = (com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix) exchange
						.getProperty("T36EODRequestProponixObj");
				com.mufg.us.amh.y73.eip.sodeod.eodmodel.Header header = t36eodRequestProponix.getHeader();
				log.error(
						"ExceptionMessageProccessor: T36 EOD xml Validation failed in T36ACKProccessor due to: {} for MessageType: {} and MessageID: {}",
						errorText, header.getMessageType(), header.getMessageID());
				t36ackHeader = new T36ACKHeader(header.getDestinationID(), header.getSenderID(),
						T36CBHConstant.ACK_MSG_TYPE, Calendar.getInstance().getTime(), Calendar.getInstance().getTime(),
						"128838301A"); // TODO: // Generate MessageID
				t36ackBody = new T36ACKBody(header.getMessageID(), T36CBHConstant.ACK_PROCSG_STATUS_FAIL,
						T36CBHConstant.ACK_ERR_CODE_MISSING, errorText);
			}
			t36ackProponix.setBody(t36ackBody);
			t36ackProponix.setHeader(t36ackHeader);
		} catch (Exception e) {
			// Prepare T36 message for malformed XML
			t36ackProponix = t36_SOD_EOD_MessageService.setTransFailureT36AckMsg(T36CBHConstant.ACK_ERR_CODE_FAILURE,
					T36CBHConstant.ACK_ERR_CODE_FAILURE_REASON, t36InputXMLReqData);
			log.error(
					"ExceptionMessageProccessor: Failed to parse T36 input XML: {} for MessageType: {} and MessageID: {}",
					errorText, t36ackProponix.getHeader().getMessageType(), t36ackProponix.getHeader().getMessageID());
			// Convert to T36 ack message to XML string and set it in exchange body
			exchange.getIn().setBody(mapper.writeValueAsString(t36ackProponix));
			return;
		}
		exchange.getIn().setBody(mapper.writeValueAsString(t36ackProponix));
	}

}
