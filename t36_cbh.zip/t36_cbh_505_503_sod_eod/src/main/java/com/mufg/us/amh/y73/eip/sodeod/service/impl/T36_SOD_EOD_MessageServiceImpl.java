package com.mufg.us.amh.y73.eip.sodeod.service.impl;

import java.util.Calendar;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.mufg.us.amh.y73.eip.sdk.constant.CBHRequestConstant;
import com.mufg.us.amh.y73.eip.sdk.constant.T36CBHConstant;
import com.mufg.us.amh.y73.eip.sdk.model.CBHInAdapterRequest;
import com.mufg.us.amh.y73.eip.sdk.model.NameValuePair;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKBody;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKHeader;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKProponix;
import com.mufg.us.amh.y73.eip.sdk.model.Transmission;
import com.mufg.us.amh.y73.eip.sdk.model.TransmissionData;
import com.mufg.us.amh.y73.eip.sdk.model.TransmissionDetails;
import com.mufg.us.amh.y73.eip.sdk.model.TransmissionRecord;
import com.mufg.us.amh.y73.eip.sodeod.service.T36_SOD_EOD_MessageService;

@Service("t36_SOD_EOD_MessageService")
public class T36_SOD_EOD_MessageServiceImpl implements T36_SOD_EOD_MessageService {

	private T36ACKProponix getT36ACKProponixObj(String messageID, String destinationID,
			String senderID) {
		T36ACKProponix t36ackProponix = new T36ACKProponix();
		T36ACKHeader t36ackHeader;
		T36ACKBody t36ackBody;
		t36ackHeader = new T36ACKHeader(senderID, destinationID, T36CBHConstant.ACK_MSG_TYPE,
				Calendar.getInstance().getTime(), Calendar.getInstance().getTime(), "128838301A"); // TODO:
		// Generate
		// messageID
		t36ackBody = new T36ACKBody(messageID, T36CBHConstant.ACK_PROCSG_STATUS_OKAY, "", "");
		t36ackProponix.setBody(t36ackBody);
		t36ackProponix.setHeader(t36ackHeader);
		return t36ackProponix;
	}

	private CBHInAdapterRequest getCBHINAdapterRequestObj(String messageID, String operationOrganizationID,
			String messageType, String senderID, String businessDate, String inputXML, String exchangeID) {
		CBHInAdapterRequest cbhInAdapterRequest = new CBHInAdapterRequest();
		TransmissionData transmissionData = new TransmissionData();
		TransmissionRecord transmissionRecord = new TransmissionRecord();
		TransmissionDetails transmissionDetails = new TransmissionDetails();
		NameValuePair nameValuePair = new NameValuePair();
		Transmission transmission = new Transmission();
		transmission.setAlternativeIdentifier(messageID);
		transmission.setBusinessDate(businessDate);
		transmission.setChannelIdentifier(senderID);
		transmission.setCorrelationIdentifier("EIP-" + UUID.randomUUID().toString().replaceAll("-", ""));
		transmission.setData(inputXML);
		transmission.setDirectionCode(CBHRequestConstant.DIR_CODE_IN);
		transmission.setInitiatorFlag(CBHRequestConstant.CBH_TRANS_INITIATOR_FLAG);
		transmission.setMessageIdentifier(exchangeID.replace("ID:", ""));
		transmission.setStatusCode(CBHRequestConstant.CBH_TRANS_STATUS_CODE_INSERTED);
		transmission.setTransmissionTypeName(operationOrganizationID);
		nameValuePair.setName(CBHRequestConstant.OPERATION_ORG_ID);
		nameValuePair.setValue(operationOrganizationID);
		transmissionDetails.setNameValuePair(nameValuePair);
		transmissionRecord.setTransmission(transmission);
		transmissionRecord.setTransmissionDetails(transmissionDetails);
		transmissionData.setTransmissionRecord(transmissionRecord);
		cbhInAdapterRequest.setTransmissionData(transmissionData);
		return cbhInAdapterRequest;
	}

	@Override
	public T36ACKProponix prepareT36AckSODMessage(
			com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix t36sodRequestProponix) {
		com.mufg.us.amh.y73.eip.sodeod.sodmodel.Header header = t36sodRequestProponix.getHeader();
		return getT36ACKProponixObj(header.getMessageID(), header.getDestinationID(), header.getSenderID());

	}

	@Override
	public T36ACKProponix prepareT36AckEODMessage(
			com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix t36eodRequestProponix) {
		com.mufg.us.amh.y73.eip.sodeod.eodmodel.Header header = t36eodRequestProponix.getHeader();
		return getT36ACKProponixObj(header.getMessageID(), header.getDestinationID(), header.getSenderID());

	}

	@Override
	public CBHInAdapterRequest prepareEODCBHInAdapterRequest(
			com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix t36eodRequestProponix, String inputXML,
			String exchangeID) {
		com.mufg.us.amh.y73.eip.sodeod.eodmodel.Header header = t36eodRequestProponix.getHeader();
		CBHInAdapterRequest cbhInAdapterRequest = getCBHINAdapterRequestObj(header.getMessageID(), header.getOperationOrganizationID(), 
				header.getMessageType(), header.getSenderID(), t36eodRequestProponix.getBody().getCurrentBusinessDate(), inputXML, exchangeID);
		return cbhInAdapterRequest;
	}

	@Override
	public CBHInAdapterRequest prepareSODCBHInAdapterRequest(com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix t36sodRequestProponix, String inputXML,
			String exchangeID) {
		com.mufg.us.amh.y73.eip.sodeod.sodmodel.Header header = t36sodRequestProponix.getHeader();
		CBHInAdapterRequest cbhInAdapterRequest = getCBHINAdapterRequestObj(header.getMessageID(), header.getOperationOrganizationID(), 
				header.getMessageType(), header.getSenderID(), t36sodRequestProponix.getBody().getCurrentBusinessDate(), inputXML, exchangeID);
		return cbhInAdapterRequest;
	}

	@Override
	public T36ACKProponix setTransFailureT36AckMsg(String errorCode, String errorText, String t36InputReqData) {
		String messageID = "";
		String finalMessageID = "";
		T36ACKProponix t36ackProponix = new T36ACKProponix();
		T36ACKHeader t36ackHeader;
		if (t36InputReqData.contains(T36CBHConstant.MESSAGEID_START_TAG)) {
			int msgIDStartTagIndx = t36InputReqData.indexOf(T36CBHConstant.MESSAGEID_START_TAG);
			messageID = t36InputReqData.substring(msgIDStartTagIndx).substring(11);
			int msgIDEndTagIndx = messageID.indexOf(T36CBHConstant.MESSAGEID_END_TAG);

			finalMessageID = (String) messageID.subSequence(0, msgIDEndTagIndx);
		}
		t36ackHeader = new T36ACKHeader(T36CBHConstant.PROPONIX_HEADER_SENDERID,
				T36CBHConstant.PROPONIX_HEADER_DESTINATIONID, T36CBHConstant.ACK_MSG_TYPE,
				Calendar.getInstance().getTime(), Calendar.getInstance().getTime(), "128838301A"); // TODO: Generate //
																									// MessageID
		T36ACKBody t36rackBody = new T36ACKBody(finalMessageID, T36CBHConstant.ACK_PROCSG_STATUS_FAIL, errorCode, errorText);
		t36ackProponix.setBody(t36rackBody);
		t36ackProponix.setHeader(t36ackHeader);
		return t36ackProponix;

	}
	
}