package com.mufg.us.amh.y73.eip.sodeod.processor;

import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.mufg.us.amh.y73.eip.sdk.constant.T36CBHConstant;
import com.mufg.us.amh.y73.eip.sdk.model.T36ACKProponix;
import com.mufg.us.amh.y73.eip.sodeod.constant.T36SODEODConstant;
import com.mufg.us.amh.y73.eip.sodeod.service.T36_SOD_EOD_MessageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class T36ACKProccessor implements Processor {

	@Autowired
	private T36_SOD_EOD_MessageService t36_SOD_EOD_MessageService;

	@Value("${spring.t36sodinputqname}")
	private String t36sodinputqname;

	@Value("${spring.t36eodinputqname}")
	private String t36eodinputqname;

	public void process(Exchange exchange) throws Exception {
		String xmlString = exchange.getIn().getBody(String.class);
		JAXBContext jaxbContext;
		T36ACKProponix t36ackProponix;
		Schema schema;
		com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix t36eodRequestProponix;
		com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix t36sodRequestProponix;
		// Re-use the xml input data in the message processor
		exchange.setProperty(T36CBHConstant.T36_INPUT_XML_DATA_NAME, xmlString);
		try {

			SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			if (exchange.getFromEndpoint().getEndpointUri().replace("activemq://queue:", "").equals(t36sodinputqname)) {
				jaxbContext = JAXBContext.newInstance(com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix.class);
				log.debug("T36ACKProccessor: Validate T36 SOD Request XML data against XSD Schema");
				schema = factory.newSchema(
						T36ACKProccessor.class.getResource(T36SODEODConstant.T36_SOD_INPUT_XML_SCHEMA_MAPPING_NAME));
			} else {
				jaxbContext = JAXBContext.newInstance(com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix.class);
				log.debug("T36ACKProccessor: Validate T36 EOD Request XML data against XSD Schema");
				schema = factory.newSchema(
						T36ACKProccessor.class.getResource(T36SODEODConstant.T36_EOD_INPUT_XML_SCHEMA_MAPPING_NAME));
			}
			Validator validator = schema.newValidator();
			// Validating t36 sod input xml over mapping xsd file
			validator.validate(new StreamSource(new StringReader(xmlString)));
			// Create Unmarshaller
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			jaxbUnmarshaller.setSchema(schema);
			if (exchange.getFromEndpoint().getEndpointUri().replace("activemq://queue:", "").equals(t36sodinputqname)) {
				t36sodRequestProponix = (com.mufg.us.amh.y73.eip.sodeod.sodmodel.Proponix) jaxbUnmarshaller.unmarshal(new StringReader(xmlString));
				log.debug(
						"T36ACKProccessor: T36 SOD Request XML data validation is successfull for MessageType: {}, MessageId: {}, OperationOrgID: {}",
						t36sodRequestProponix.getHeader().getMessageType(),
						t36sodRequestProponix.getHeader().getMessageID(),
						t36sodRequestProponix.getHeader().getOperationOrganizationID());
				t36ackProponix = t36_SOD_EOD_MessageService.prepareT36AckSODMessage(t36sodRequestProponix);
				exchange.setProperty("T36SODRequestProponixObj", t36sodRequestProponix);
			} else {
				t36eodRequestProponix = (com.mufg.us.amh.y73.eip.sodeod.eodmodel.Proponix) jaxbUnmarshaller.unmarshal(new StringReader(xmlString));
				log.debug(
						"T36ACKProccessor: T36 EOD Request XML data validation is successfull for MessageType: {}, MessageId: {}, OperationOrgID: {}",
						t36eodRequestProponix.getHeader().getMessageType(),
						t36eodRequestProponix.getHeader().getMessageID(),
						t36eodRequestProponix.getHeader().getOperationOrganizationID());
				t36ackProponix = t36_SOD_EOD_MessageService.prepareT36AckEODMessage(t36eodRequestProponix);
				exchange.setProperty("T36EODRequestProponixObj", t36eodRequestProponix);
			}
			XmlMapper mapper = new XmlMapper();
			exchange.getIn().setHeader("CCSID", T36CBHConstant.ACK_CCSID);
			exchange.getIn().setHeader("Encoding", T36CBHConstant.ACK_ENCODING);
			exchange.getIn().setBody(mapper.writeValueAsString(t36ackProponix));
		} catch (Exception e) {
			exchange.setException(new Throwable(e.getMessage()));
			throw e;
		}

	}
}
