package com.mufg.us.amh.y73.eip.sodeod.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.mufg.us.amh.y73.eip.sdk.constant.T36CBHConstant;
import com.mufg.us.amh.y73.eip.sodeod.processor.CBHMessageProccessor;
import com.mufg.us.amh.y73.eip.sodeod.processor.ExceptionMessageProccessor;
import com.mufg.us.amh.y73.eip.sodeod.processor.T36ACKProccessor;

@Component
public class EIP_T36_505_503_SOD_EOD_Route extends RouteBuilder {

	@Value("${spring.t36sodinputqname}")
	private String t36sodinputqname;

	@Value("${spring.t36eodinputqname}")
	private String t36eodinputqname;

	@Value("${spring.t36ackqueuename}")
	private String t360QName;

	@Value("${spring.cbhqueuename}")
	private String cbhQName;

	@Autowired
	private T36ACKProccessor t36ackProccessor;

	@Autowired
	private CBHMessageProccessor cbhMessageProccessor;

	@Autowired
	private ExceptionMessageProccessor exceptionMessageProccessor;

	@Override
	public void configure() throws Exception {

		// Listen SOD input queue from AMQ bridge
		from(T36CBHConstant.ACTIVEMQ_QUEUE + t36sodinputqname).doTry().process(t36ackProccessor)
				.toD(T36CBHConstant.ACTIVEMQ_QUEUE + t360QName).process(cbhMessageProccessor)
				.toD(T36CBHConstant.ACTIVEMQ_QUEUE + cbhQName).doCatch(Exception.class) // TODO: Use standard pattern
																						// for exception.
				.process(exceptionMessageProccessor).toD(T36CBHConstant.ACTIVEMQ_QUEUE + t360QName).end();

		// Listen EOD input queue from AMQ bridge
		from(T36CBHConstant.ACTIVEMQ_QUEUE + t36eodinputqname).doTry().process(t36ackProccessor)
				.toD(T36CBHConstant.ACTIVEMQ_QUEUE + t360QName).process(cbhMessageProccessor)
				.toD(T36CBHConstant.ACTIVEMQ_QUEUE + cbhQName).doCatch(Exception.class)
				.process(exceptionMessageProccessor).toD(T36CBHConstant.ACTIVEMQ_QUEUE + t360QName).end();
	}
}
