package com.mufg.us.amh.y73.eip.sodeod.constant;

public final class T36SODEODConstant{
	
	private T36SODEODConstant() {
		
	}
	
	public static final String T36_SOD_INPUT_XML_SCHEMA_MAPPING_NAME = "/SODMESS.xsd";
	public static final String T36_EOD_INPUT_XML_SCHEMA_MAPPING_NAME = "/EODMESS.xsd";

}
