package com.mufg.us.amh.y73.eip.sodeod.config;

import org.springframework.context.annotation.Configuration;

import com.mufg.us.amh.y73.eip.sdk.config.AMQConfig;

@Configuration
public class JMS_SOD_Config extends AMQConfig{

}
